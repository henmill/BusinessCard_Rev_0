#include <atmel_start.h>
#include <stdio.h>

/*----------------------------------------------------------------------------
 *   Extern variables
 *----------------------------------------------------------------------------*/
extern volatile uint8_t measurement_done_touch;

/*----------------------------------------------------------------------------
 *   Global variables
 *----------------------------------------------------------------------------*/
uint16_t scroll_val = 0;

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

	/* Replace with your application code */
	while (1) {
		
		touch_process();
		
		if(measurement_done_touch){
			measurement_done_touch = 0;
			
			scroll_val = get_scroller_position(0);
			
		}
		
	}
}
