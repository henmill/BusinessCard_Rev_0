#include <atmel_start.h>
#include <stdio.h>
#include <util/delay.h>

/*----------------------------------------------------------------------------
 *   Extern variables
 *----------------------------------------------------------------------------*/
extern volatile uint8_t measurement_done_touch;
extern volatile uint8_t t1callbackflag;

/*----------------------------------------------------------------------------
 *   Global variables
 *----------------------------------------------------------------------------*/
uint16_t scroll_val = 0;

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	
	LED1_set_level(true); _delay_ms(100);
	LED2_set_level(true); _delay_ms(100);
	LED3_set_level(true); _delay_ms(100);
	LED4_set_level(true); _delay_ms(100);
	LED5_set_level(true); _delay_ms(100);
	LED6_set_level(true); _delay_ms(100);
	LED7_set_level(true); _delay_ms(100); _delay_ms(200);
	
	LED1_set_level(false);
	LED2_set_level(false);
	LED3_set_level(false);
	LED4_set_level(false);
	LED5_set_level(false);
	LED6_set_level(false);
	LED7_set_level(false);

	/* Replace with your application code */
	while (1) 
	{
		
		touch_process();
		
		if(measurement_done_touch){
			measurement_done_touch = 0;
			
			scroll_val = get_scroller_position(0);
			
		}
		
		if(t1callbackflag){
			t1callbackflag = 0;		//reset the flag
			
			//printf("%d \r\n",scroll_val);
		}
		
	}
}
