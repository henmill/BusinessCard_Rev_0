#include <atmel_start.h>
#include <stdio.h>
#include <util/delay.h>

void slider_to_state(void);
void state_to_LED(uint8_t state);
void sleep_init(void);

/*----------------------------------------------------------------------------
 *   Extern variables (originally declared elsewhere)
 *----------------------------------------------------------------------------*/
extern volatile uint8_t measurement_done_touch;
extern volatile uint8_t t1callbackflag;
extern volatile uint16_t t1cnt;
extern volatile uint16_t t1cntmax;

extern volatile uint16_t sleep_timer;
extern volatile uint16_t wakecnt;

/*----------------------------------------------------------------------------
 *   Global variables
 *----------------------------------------------------------------------------*/
volatile uint16_t scroll_val = 0;
volatile uint16_t old_scroll_val = 0;
volatile uint8_t slider_status = 0;
volatile uint8_t LED_state = 0;	

/*----------------------------------------------------------------------------
 *   State flags
 *----------------------------------------------------------------------------*/
volatile uint8_t awake = 1;


int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	
	//sleep_init();
	//sleep_enter();
	//SLEEP_MODE_PWR_SAVE  --> PTC can wake from power save mode according to datasheet
	//Power Save mode is supposed to keep main clock going for PTC so
	
	// light up the leds sequentially on startup
	/*
	
					  *	4	
				  3*	  *5
				 2*		   *6
				    1*    *7
	*/
	LED1_set_level(true); _delay_ms(60); LED1_set_level(false);
	LED2_set_level(true); _delay_ms(60); LED2_set_level(false);
	LED3_set_level(true); _delay_ms(60); LED3_set_level(false);
	LED4_set_level(true); _delay_ms(60); LED4_set_level(false);
	LED5_set_level(true); _delay_ms(60); LED5_set_level(false);
	LED6_set_level(true); _delay_ms(60); LED6_set_level(false);
	LED7_set_level(true); _delay_ms(60); LED7_set_level(false);
	LED6_set_level(true); _delay_ms(60); LED6_set_level(false);
	LED5_set_level(true); _delay_ms(60); LED5_set_level(false);
	LED4_set_level(true); _delay_ms(60); LED4_set_level(false);
	LED3_set_level(true); _delay_ms(60); LED3_set_level(false);
	LED2_set_level(true); _delay_ms(60); LED2_set_level(false);
	LED1_set_level(true); _delay_ms(60); LED1_set_level(false);
	

	/* Replace with your application code */
	while (1) 
	{
	
		if(awake == 1u){
			touch_process();
		}
		else{
			//sleep_enter();
		}
		//touch_process();
				
		//current overflow ~8.2ms
		//t1callbackflag is set in driver_isr ISR(TIMER1_OVF_vect)
		if(t1callbackflag == 1)
		{
			t1callbackflag = 0;	
			
			
			/*	
			//if(measurement_done_touch){
				//measurement_done_touch = 0;
				//
				//slider_status = get_scroller_state(0);
				//scroll_val = get_scroller_position(0);
				//
				//if(slider_status != 0u){		//if slider has anything going on, process it
					//slider_to_state();
				//}
				//else{						//otherwise, turn off LEDs
					//LED_state = 0;
				//}
				//
				//state_to_LED(LED_state);	//decode slider position to LEDs
			//}
			*/
			
			
			//t1cnt++;
			//wakecnt++;
			
			//if(t1cnt >= 1)		//if t1cnt = 5, 5x8.2 = 41ms --> the effective "check frequency"
			//{
			//	t1cnt = 0;
				
				if(measurement_done_touch){
					measurement_done_touch = 0;
					
					slider_status = get_scroller_state(0);
					scroll_val = get_scroller_position(0);
					
					if(slider_status != 0u){		//if slider has anything going on, process it
						sleep_timer = 0;			//this should keep it awake
						slider_to_state();
					}
					else{							//otherwise, turn off LEDs
						LED_state = 0;
						sleep_timer++;				//sleep timer increments every t1cntmax (5) * 8.2ms t1callback = 41ms
					}
					if(sleep_timer > 122){			//122 * 41ms ~= 5.002s
						sleep_timer = 0;
						awake = 0;					//set the awake flag low
					}
					else{;}//sleep_timer = 0;}		//reset the count so it doesn't try to sleep every time?
				}
				state_to_LED(LED_state);	//decode slider position to LEDs
			//}
			
			//if (wakecnt > 600){
				//wakecnt = 0;
				//awake = 1;
			//}
			
		}	
		
	}
}

void slider_to_state(void)
{
	if(scroll_val <= 146){
		LED_state = 1;
	}
	else if((scroll_val > 147)&&(scroll_val <= 292))
	{
		LED_state = 2;
	}
	else if((scroll_val > 293)&&(scroll_val <= 438))
	{
		LED_state = 3;
	}
	else if((scroll_val > 439)&&(scroll_val <= 585))
	{
		LED_state = 4;
	}
	else if((scroll_val > 586)&&(scroll_val <= 731))
	{
		LED_state = 5;
	}
	else if((scroll_val > 732)&&(scroll_val <= 877))
	{
		LED_state = 6;
	}
	else if(scroll_val > 873){
		LED_state = 7;
	}
}

void state_to_LED(uint8_t state)
{
	switch(state)
	{
		case 0: LED1_set_level(false);LED2_set_level(false);LED3_set_level(false);LED4_set_level(false);LED5_set_level(false);LED6_set_level(false);LED7_set_level(false);
				break;
		case 1: LED1_set_level(true); 
				LED2_set_level(false); LED3_set_level(false);LED4_set_level(false); 
				LED5_set_level(false); LED6_set_level(false);LED7_set_level(false);
				break;
		case 2: LED2_set_level(true); 
				LED1_set_level(false); LED3_set_level(false);LED4_set_level(false);
				LED5_set_level(false); LED6_set_level(false);LED7_set_level(false);
				break;
		case 3: LED3_set_level(true); 
				LED1_set_level(false); LED2_set_level(false);LED4_set_level(false);
				LED5_set_level(false); LED6_set_level(false);LED7_set_level(false);
				break;
		case 4: LED4_set_level(true); 
				LED1_set_level(false); LED2_set_level(false);LED3_set_level(false); 
				LED5_set_level(false); LED6_set_level(false);LED7_set_level(false);
				break;
		case 5: LED5_set_level(true); 
				LED1_set_level(false); LED2_set_level(false);LED3_set_level(false); 
				LED4_set_level(false); LED6_set_level(false);LED7_set_level(false);
				break;
		case 6: LED6_set_level(true); 
				LED1_set_level(false); LED2_set_level(false);LED3_set_level(false); 
				LED4_set_level(false); LED5_set_level(false);LED7_set_level(false);
				break;
		case 7: LED7_set_level(true); 
				LED1_set_level(false); LED2_set_level(false);LED3_set_level(false); 
				LED4_set_level(false); LED5_set_level(false);LED6_set_level(false);
				break;
		default: LED1_set_level(false);LED2_set_level(false);LED3_set_level(false);LED4_set_level(false);LED5_set_level(false);LED6_set_level(false);LED7_set_level(false);
				break;
	}
}

void sleep_init(void)
{
	set_sleep_mode(SLEEP_MODE_PWR_SAVE);
	
}